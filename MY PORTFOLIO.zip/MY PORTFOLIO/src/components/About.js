import React from 'react';
import Fade from 'react-reveal/Fade';

// Import your profile picture and icons
import profilepic from '../assets/profile_photo.jpeg';
import linkedinIcon from '../assets/linkedin.png'; 
import githubIcon from '../assets/github.png';
import emailIcon from '../assets/email.png'; // Add the path to your email icon

const About = () => {
  return (
    <section id="about">
      
        <h1 className="heading">About Me</h1>
      
      <div className="content">
        <div className="summary">
          <Fade bottom>
            <p>Hello! I'm Sakshi Paste, pursuing a B.Tech in Electronics and Telecommunications Engineering with a focus on Artificial Intelligence and Machine Learning at MIT Academy of Engineering, Pune. My passion for Machine Learning and Fullstack Development drives me to create innovative solutions and tackle complex challenges in software technology. I am eager to apply my skills and aspirations to make a meaningful impact in the tech industry.</p>
          </Fade>
          <Fade bottom>
            <a href="/path/to/your-resume.pdf" target="_blank" rel="noopener noreferrer" className="resume-button">
              Resume/CV
            </a>
          </Fade>
          <Fade bottom>
            <div className="contact-links">
              <a href="https://www.linkedin.com/in/yourprofile" target="_blank" rel="noopener noreferrer">
                <img src={linkedinIcon} alt="LinkedIn" className="contact-icon" />
              </a>
              <a href="https://github.com/yourprofile" target="_blank" rel="noopener noreferrer">
                <img src={githubIcon} alt="GitHub" className="contact-icon" />
              </a>
              <a href="mailto:your-email@example.com">
                <img src={emailIcon} alt="Email" className="contact-icon" />
              </a>
            </div>
          </Fade>
        </div>
        <div className="photo">
          <Fade bottom>
            <img src={profilepic} alt="Your Name" />
          </Fade>
        </div>
      </div>
    </section>
  );
};

export default About;
