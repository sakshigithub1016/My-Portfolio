import React from 'react';
import Fade from 'react-reveal/Fade';
import schoolIcon from '../assets/school-icon.png'; // Path to your icon
import collegeIcon from '../assets/college-icon.png'; // Path to your icon

const Education = () => {
  return (
    <section id='education' className="resume-education">
      <h2>Education</h2>
      
      <Fade bottom delay={100}>
        <div className="education-item">
          <img src={collegeIcon} alt="College" />
          <div>
            <h3>MIT Academy of Engineering, Pune</h3>
            <p>B.Tech. - Electronics and Telecommunication Engineering</p>
            <p>2021 - 2025</p>
            <p>CGPA: 8.17 / 10</p>
          </div>
        </div>
      </Fade>
      
      <Fade bottom delay={200}>
        <div className="education-item">
          <img src={schoolIcon} alt="School" />
          <div>
            <h3>Kendriya Vidyalaya BEG, Pune-06</h3>
            <p>12th | Central Board of Secondary Education (CBSE)</p>
            <p>2020</p>
            <p>Percentage: 76 / 100</p>
          </div>
        </div>
      </Fade>
      
      <Fade bottom delay={300}>
        <div className="education-item">
          <img src={schoolIcon} alt="School" />
          <div>
            <h3>Kendriya Vidyalaya BEG, Pune-06</h3>
            <p>10th | Central Board of Secondary Education (CBSE)</p>
            <p>2018</p>
            <p>Percentage: 84.60 / 100</p>
          </div>
        </div>
      </Fade>
    </section>
  );
};

export default Education;
