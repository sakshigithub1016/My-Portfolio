import React from 'react';
import Fade from 'react-reveal/Fade';
import internshipPhoto from '../assets/internship.jpg'; // Update the path as needed

const Experience = () => {
  return (
    <section id='experience' className="resume-experience">
      <h2>Experience</h2>

      <Fade bottom>
        <div className="job">
          <div className="job-content">
            <div className="job-details">
              <h3>Intern - Fullstack Developer</h3>
              <p>Fourise Software Solutions Pvt. Ltd</p>
              <p>Key Skills: HTML, CSS, JavaScript</p>
              <p>Link: <a href="https://github.com/santoshiofficial/Ambica_Jewellery" target="_blank" rel="noopener noreferrer">https://github.com/santoshiofficial/Ambica_Jewellery</a></p>
              <ul>
                <li>Collaborated with a team on a live e-commerce project, focusing on front-end development.</li>
                <li>Developed responsive and user-friendly web pages using HTML, CSS, and JavaScript.</li>
                <li>Worked closely with designers to ensure an optimal user experience and seamless UI implementation.</li>
                <li>Enhanced the design and functionality of the e-commerce website to improve overall performance and user engagement.</li>
              </ul>
            </div>
            <img 
              src={internshipPhoto} 
              alt="Internship Experience" 
              className="job-photo"
            />
          </div>
        </div>
      </Fade>

      {/* Add more job experiences as needed */}
    </section>
  );
};

export default Experience;
