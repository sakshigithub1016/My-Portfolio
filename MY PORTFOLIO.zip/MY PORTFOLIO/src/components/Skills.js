import React from 'react';
import Fade from 'react-reveal/Fade';

// Import skill images
import aiMlIcon from '../assets/ai-ml.png'; // Add the appropriate path to your image
import htmlIcon from '../assets/html.png';
import cssIcon from '../assets/css.png';
import jsIcon from '../assets/js.png';
import reactIcon from '../assets/react.png';
import nodeIcon from '../assets/node.png';
import python from '../assets/python.png';

const skills = [
  { src: aiMlIcon, alt: 'Artificial Intelligence & Machine Learning', label: 'AI-ML', link: 'https://example.com/ai-ml' },
  { src: python, alt: 'Python', label: 'Python', link: 'https://example.com/python' },
  { src: htmlIcon, alt: 'HTML', label: 'HTML', link: 'https://example.com/html' },
  { src: cssIcon, alt: 'CSS', label: 'CSS', link: 'https://example.com/css' },
  { src: jsIcon, alt: 'JavaScript', label: 'JavaScript', link: 'https://example.com/javascript' },
  { src: reactIcon, alt: 'React.js', label: 'React.js', link: 'https://example.com/react' },
  { src: nodeIcon, alt: 'Node.js', label: 'Node.js', link: 'https://example.com/node' }
];

const Skills = () => {
  return (
    <section id="skills" className="resume-skills">
      <h2>Skills</h2>
      <div className="skills-container">
        {skills.map((skill, index) => (
          <Fade bottom delay={index * 100} key={index}>
            <a href={skill.link} className="skill">
              <img src={skill.src} alt={skill.alt} className="skill-icon" />
              <p>{skill.label}</p>
            </a>
          </Fade>
        ))}
      </div>
    </section>
  );
};

export default Skills;
