import React from 'react';
import Fade from 'react-reveal/Fade';
import armyImage from '../assets/ncc.jpg';  // Update with actual image path
import volunteerImage from '../assets/volunteer.jpg';  // Update with actual image path

const ExtracurricularActivities = () => {
  return (
    <section id='extra' className="resume-extracurricular">
      <Fade>
        <h2>Extracurricular Activities</h2>
      </Fade>
      <div className="activity-container">
        <Fade bottom>
          <div className="activity">
            <h3>National Cadet Corps (Army Wing)</h3>
            <div className="activity-content">
              <div className="activity-text">
                <p>
                  Participated in various training programs and camps, developing leadership skills, discipline, and teamwork. Engaged in community service and national integration activities.
                </p>
              </div>
              <div className="activity-image">
                <img src={armyImage} alt="Army Activity" />
              </div>
            </div>
          </div>
        </Fade>
        <Fade bottom>
          <div className="activity">
            <h3>Volunteer at iVolunteer India</h3>
            <div className="activity-content">
              <div className="activity-text">
                <p>
                  Contributed to several community development projects, including workshops at local NGOs and organizing social services such as cleanliness drives. Assisted in planning and executing events aimed at improving community welfare, gaining experience in project management and community engagement.
                </p>
              </div>
              <div className="activity-image">
                <img src={volunteerImage} alt="Volunteer Activity" />
              </div>
            </div>
          </div>
        </Fade>
        {/* Add more activities as needed */}
      </div>
    </section>
  );
};

export default ExtracurricularActivities;
