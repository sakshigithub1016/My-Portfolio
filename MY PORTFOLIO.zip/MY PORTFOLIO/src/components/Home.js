import React from 'react';

const Home = () => {
  return (
    <section id="home" className="home-section">
      <div className="home-container">
        <div className="text-content">
          <h2>Hi, I'm Sakshi Paste</h2>
          <em><p>Turning ideas into reality with Machine Learning and Front-End Development, crafting impactful digital experiences.</p></em>
        </div>
      </div>
    </section>
  );
};

export default Home;
