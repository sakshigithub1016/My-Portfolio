import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Fade from 'react-reveal/Fade';

const Projects = () => {
  const [activeProject, setActiveProject] = useState(null);

  const toggleProject = (index) => {
    setActiveProject(activeProject === index ? null : index);
  };

  return (
    <section id='projects' className="resume-projects">
      <h2>Projects</h2>

      {/* Grid for Projects */}
      <div className="project-grid">
        {/* Project 1 */}
        <div className="project-box" onClick={() => toggleProject(0)}>
          <Fade bottom>
            <h3>Automated System with On-Off Delay Configurable Timer</h3>
          </Fade>
        </div>

        {/* Project 2 */}
        <div className="project-box" onClick={() => toggleProject(1)}>
          <Fade bottom>
            <h3>Personalized Medical Recommendation System with Machine Learning</h3>
          </Fade>
        </div>

        {/* Project 3 */}
        <div className="project-box" onClick={() => toggleProject(2)}>
          <Fade bottom>
            <h3>Text Summarization using Natural Language Processing</h3>
          </Fade>
        </div>

        {/* Project 4 */}
        <div className="project-box" onClick={() => toggleProject(3)}>
          <Fade bottom>
            <h3>Front-End Web Development</h3>
          </Fade>
        </div>
      </div>

      {/* Modal for Project Details */}
      <AnimatePresence>
        {activeProject !== null && (
          <motion.div
            className="modal-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="modal-content"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              transition={{ duration: 0.3 }}
            >
              <button className="modal-close" onClick={() => setActiveProject(null)}>✕</button>
              {activeProject === 0 && (
                <div>
                  <h3>Automated System with On-Off Delay Configurable Timer</h3>
                  <p><strong>Mentor:</strong> Prof. Vikrant Verma (MITAOE)</p>
                  <p><strong>Team Size:</strong> 4</p>
                  <p><strong>Key Skills:</strong> PCB Design, Proteus, Embedded C</p>
                  <p>
                    Designed and implemented a microcontroller-based automatic socket control system for remote appliance management.
                    Technologies used: 8051 Microcontroller, 16*2 LCD, Eagle.
                  </p>
                </div>
              )}
              {activeProject === 1 && (
                <div>
                  <h3>Personalized Medical Recommendation System with Machine Learning</h3>
                  <p><strong>Team Size:</strong> 3</p>
                  <p><strong>Key Skills:</strong> Machine Learning, Python Programming, HTML, CSS</p>
                  <p>
                    Developed a machine learning-based personalized medical recommendation system using Flask to predict diseases 
                    and provide tailored medicine, prescription, and workout recommendations, focusing on user privacy and continuous improvement.
                  </p>
                  <a href="https://github.com/sakshigithub1016/PERSONALIZED-MEDICAL-RECOMMENDATION-SYSTEM-WITH-MACHINE-LEARNING" target="_blank" rel="noopener noreferrer">View Project</a>
                </div>
              )}
              {activeProject === 2 && (
                <div>
                  <h3>Text Summarization using Natural Language Processing</h3>
                  <p><strong>Key Skills:</strong> Python Programming, Machine Learning, Deep Learning</p>
                  <p>
                    Developed a text summarization solution using advanced NLP and ML techniques with SpaCy and Transformers, improving 
                    information processing and user accessibility.
                  </p>
                  <a href="https://github.com/sakshigithub1016/TEXT-SUMMARIZATION-USING-NATURAL-LANGUAGE-PROCESSING" target="_blank" rel="noopener noreferrer">View Project</a>
                </div>
              )}
              {activeProject === 3 && (
                <div>
                  <h3>Front-End Web Development</h3>
                  <p><strong>Key Skills:</strong> HTML, CSS, JavaScript, UI/UX Design, ReactJs</p>
                  <p>1. To-Do List Web Application</p>
                  <p>2. Sliders for Annotate AI</p>
                  <p>3. Memory Matching Game</p>
                  <p>4. Portfolio Website</p>
                  <a href="https://github.com/sakshigithub1016/FRONT-END-WEB-DEVELOPMENT-PROJECTS" target="_blank" rel="noopener noreferrer">View Projects</a>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
};

export default Projects;
